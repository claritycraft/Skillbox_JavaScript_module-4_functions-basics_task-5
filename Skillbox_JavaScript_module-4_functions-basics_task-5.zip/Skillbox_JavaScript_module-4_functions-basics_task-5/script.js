function hasTotalSum(price, amount, discount) {
  let totalPrice = price * amount;
  let discountAmount = (discount / 100) * totalPrice;
  let finalPrice = totalPrice - discountAmount;

  return finalPrice;
}

let priceItem = 25000;
let amountItem = 3;
let discountItem = 20;

console.log(hasTotalSum(priceItem, amountItem, discountItem));
